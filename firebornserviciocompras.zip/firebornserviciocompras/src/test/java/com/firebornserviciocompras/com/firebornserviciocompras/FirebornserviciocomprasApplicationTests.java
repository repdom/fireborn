package com.firebornserviciocompras.com.firebornserviciocompras;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FirebornserviciocomprasApplicationTests {

	@Test
	public void contextLoads() {
	}

}
