package com.firebornserviciocompras.com.firebornserviciocompras;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirebornserviciocomprasApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirebornserviciocomprasApplication.class, args);
	}

}
